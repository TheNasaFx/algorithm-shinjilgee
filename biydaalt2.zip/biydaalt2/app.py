from flask import Flask, render_template, request, jsonify
from collections import Counter
from spylls.hunspell import Dictionary

app = Flask(__name__)

# Initialize Hunspell
hunspell_instance = Dictionary.from_files('mn')  # Ensure 'mn.dic' and 'mn.aff' are in the working directory

# Define the root route
@app.route('/')
def index():
    return render_template('index.html')

# Process text route
@app.route('/process', methods=['POST'])
def process():
    data = request.get_json()
    text = data.get("text", "")
    # Dummy text processing for now
    result = {
        "processed_text": text,
        "misspelled_words": {},
        "unique_word_count": len(set(text.split())),
        "top_10_words": {}
    }
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
